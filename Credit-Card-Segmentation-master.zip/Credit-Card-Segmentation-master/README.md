# Credit-Card-Segmentation
This problem requires clusters of users to lay down the market strategy. The dataset summarizes the usage behavior of over 9000 customers for around 6 months.
#### K Means Clustering
###### 4 Clusters
![4clusters](https://user-images.githubusercontent.com/20225277/47753522-d5e0a880-dcbd-11e8-9c8e-328c0a311c45.png)
###### 5 Clusters
![5clusters](https://user-images.githubusercontent.com/20225277/47753510-cd886d80-dcbd-11e8-8945-3c78ff8dba46.png)
###### 6 Clusters
![6clusters](https://user-images.githubusercontent.com/20225277/47753516-d24d2180-dcbd-11e8-9fc2-1ab7b91c65b3.png)
